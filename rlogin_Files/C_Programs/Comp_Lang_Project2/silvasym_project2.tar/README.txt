Mike Silvasy
Project 2 - README.txt

ldd (GNU libc) 2.28 --> Current version of C in rlogin (as of 11/10/2020)

To run the program, compile the source file (project2.c) and create an executable "project2" using the following:
    gcc project2.c -o project2
After compilation, run the executable using the following:
    ./project2

** I wasn't sure if we needed a README.txt, so I added one just in case.